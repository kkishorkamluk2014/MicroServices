package com.kk.ecommerce.service;

import org.springframework.stereotype.Service;

import com.kk.ecommerce.dto.OrderDto;



@Service
public interface OrderService {

	String orderProduct(OrderDto orderDto);

}
