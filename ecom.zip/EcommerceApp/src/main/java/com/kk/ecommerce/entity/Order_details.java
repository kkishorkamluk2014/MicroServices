package com.kk.ecommerce.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;

@Entity
public class Order_details {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long order_Details_id;
	@OneToOne (cascade = CascadeType.ALL)
	@JoinColumn (name = "product_Id")
	private Product product;
	@NotEmpty
	private int quantity;
	@NotEmpty
	private double price;
	
	public Long getOrder_Details_id() {
		return order_Details_id;
	}
	public void setOrder_Details_id(Long order_Details_id) {
		this.order_Details_id = order_Details_id;
	}
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
