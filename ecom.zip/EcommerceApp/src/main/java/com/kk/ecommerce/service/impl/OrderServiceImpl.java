package com.kk.ecommerce.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.kk.ecommerce.dto.OrderDto;
import com.kk.ecommerce.entity.Order;
import com.kk.ecommerce.repository.OrderRepository;
import com.kk.ecommerce.repository.ProductRepository;
import com.kk.ecommerce.service.OrderService;


@Service
public class OrderServiceImpl implements OrderService {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);
	
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	ProductServiceImpl productServiceImpl;
	
	@Override
	public String orderProduct(OrderDto orderdetails) {
		
		
		
		
		
		
		
		
		
		
		/*
		 * // TODO Auto-generated method stub Order order=new Order(); LocalDateTime
		 * localDateTime = LocalDateTime.now(); logger.info("time:"+localDateTime);
		 * LocalDate localDate = localDateTime.toLocalDate();
		 * logger.info("date:"+localDate); LocalTime localTime =
		 * localDateTime.toLocalTime(); logger.info("datetime:"+localTime);
		 * BeanUtils.copyProperties(orderdetails, order); logger.info("After copying");
		 * try { order.setDate(java.sql.Date.valueOf(localDate));
		 * order.setTime(java.sql.Time.valueOf(localTime)); orderRepository.save(order);
		 * logger.info("Successfully placed Order"); return "Placed Order";
		 * }catch(Exception e) { logger.error("Order not placed"); return
		 * "Order not placed"; }
		 */
	}

	

}
