package com.kk.ecommerce.dto;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.kk.ecommerce.entity.User;





public class OrderDto {
	
	private Long userId;
	private Long accountno;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	
	List<ProductDto> productDto;

	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getAccountno() {
		return accountno;
	}
	public void setAccountno(Long accountno) {
		this.accountno = accountno;
	}
	
	public List<ProductDto> getProductDto() {
		return productDto;
	}
	public void setProductDto(List<ProductDto> productDto) {
		this.productDto = productDto;
	}
	
	

}
