package com.kk.ecommerce.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kk.ecommerce.dto.OrderDto;
import com.kk.ecommerce.feignclient.BankClient;
import com.kk.ecommerce.service.OrderService;






@RestController
@RequestMapping("/orders")
public class OrderController {
	Logger logger=LoggerFactory.getLogger(OrderController.class);
	@Autowired
	OrderService orderService;
	
	@Autowired
	BankClient bankClient;
	
	@PostMapping
	public ResponseEntity<?> orderProduct(@RequestBody OrderDto orderDto) {
		System.out.println(orderDto+" order dto ");
		System.out.println(orderDto.getUserId());
		System.out.println(orderDto.getAccountno());
		System.out.println(orderDto.getProductDto());
		orderDto.getProductDto().stream().map((p)->{
			return p;
		}).forEach((p1)->{
			System.out.println(p1.getProduct_Id());
			System.out.println(p1.getQuantity());
		});
		String orderdto= orderService.orderProduct(orderDto);
		if(orderdto!=null) {
			return new ResponseEntity<String>(orderdto,HttpStatus.CREATED );
		}else {
			return new ResponseEntity<String>("Did not placed Order",HttpStatus.NOT_FOUND );		
		}
	}

}
