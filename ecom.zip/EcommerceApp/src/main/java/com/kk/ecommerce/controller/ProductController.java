package com.kk.ecommerce.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kk.ecommerce.dto.ProductDto;
import com.kk.ecommerce.entity.Product;
import com.kk.ecommerce.service.ProductService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;


@RestController
@RequestMapping("/products")
public class ProductController {
	
	Logger logger=LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	ProductService productService;
	
	
	@PostMapping("/add")
	public ProductDto addProducts(@Valid @RequestBody ProductDto productDto)
	{
		logger.info("Product Added Successfully");
		return productService.addProducts(productDto);
	}
	@PostMapping
	public ResponseEntity<?> getAllProductsByNames(@Valid @Pattern(regexp = "[a-z]")@RequestParam String productname,@Valid @Pattern(regexp = "[a-z]||[A-Z]") @RequestParam String categoryname)
	{
		List<Product> productList=new ArrayList<>();
		productList= productService.getAllProductsByNames(productname, categoryname);
		if(!productList.isEmpty()) {
			logger.info("Products details");
			return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
		}
		logger.error("No products for your inputs");
		return new ResponseEntity<String>("No such product", HttpStatus.NOT_FOUND);

	}
	
	@GetMapping("/{product_Id}")
	public Product getProductById(@PathVariable Long product_Id){
		
		
		return productService.getProductById(product_Id);
	}
	

}
