package com.kk.ecommerce.service;

import com.kk.ecommerce.dto.UserDto;

public interface UserService {

	public UserDto saveUserDetails(UserDto userDto);
}
