package com.kk.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kk.ecommerce.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	
}
